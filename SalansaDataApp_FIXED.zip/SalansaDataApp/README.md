# Salansa Data Android App

Package: com.salansadata.app

This is a native Android WebView app for the Salansa Data storefront:
https://salansadatasub.dataengine.ng/

The project is configured for a Codemagic cloud build. The Codemagic workflow installs Gradle 8.9, which matches Android Gradle Plugin 8.7.x, then creates a debug APK.

No API keys, passwords, OTPs, bank PINs, or other secrets are included.

Artifact: app/build/outputs/**/*.apk
